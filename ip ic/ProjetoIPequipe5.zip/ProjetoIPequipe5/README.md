# ProjetoIPequipe5
Projeto de Introdução à Programação para criar um jogo no pygames usando Python

Membros da equipe:

Gabriel Stamford (gsa3)

Igor Fragoso (ifplm)

Pedro Dantas (phds3)

Pedro Elias (pega)

Samuell Costa (shcpc)
